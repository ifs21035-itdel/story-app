import Swal from "sweetalert2";

class HomePresenter {
  constructor({ view, model }) {
    this._view = view;
    this._model = model;

    this._loadStories();
  }

  async _loadStories() {
    this._view.showLoading();
    try {
      const stories = await this._model.getAllStories();
      this._view.displayStories(stories);
    } catch (error) {
      console.error("HomePresenter Error: Failed to load stories:", error);
      this._view.displayError(error.message);
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: `Failed to load stories: ${error.message}`,
      });
    } finally {
      this._view.hideLoading();
    }
  }
}

export default HomePresenter;
