import StoryApi from "../data/api";

const AuthHelper = {
  isUserLoggedIn() {
    return !!StoryApi.getUserToken();
  },

  updateLoginLogoutLink() {
    const authLinkContainer = document.getElementById("auth-link-container");
    if (!authLinkContainer) return;

    if (this.isUserLoggedIn()) {
      const userName = localStorage.getItem("STORY_APP_USER_NAME") || "User";
      authLinkContainer.innerHTML = `
        <span>Hi, ${userName}!</span> 
        <button id="logoutButton" class="button button-danger" style="margin-left:10px; padding: 5px 10px;">Logout</button>
      `;
      document.getElementById("logoutButton").addEventListener("click", () => {
        StoryApi.removeUserToken();
        localStorage.removeItem("STORY_APP_USER_NAME");
        this.updateLoginLogoutLink();
        window.location.hash = "#/login";
        window.dispatchEvent(new HashChangeEvent("hashchange"));
      });
    } else {
      authLinkContainer.innerHTML = '<a href="#/login">Login</a>';
    }
  },

  storeUserName(name) {
    localStorage.setItem("STORY_APP_USER_NAME", name);
  },
};

export default AuthHelper;
