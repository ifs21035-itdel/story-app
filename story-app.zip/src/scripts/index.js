import "../styles/styles.css";
import App from "./pages/app";
import AuthHelper from "./utils/auth-helper";

const app = new App({
  content: document.querySelector("#main-content"),
});

window.addEventListener("DOMContentLoaded", () => {
  AuthHelper.updateLoginLogoutLink();
  app.renderPage();
});

window.addEventListener("hashchange", () => {
  app.renderPage();
});

const skipLink = document.querySelector(".skip-link");
const mainContent = document.querySelector("#main-content");

if (skipLink && mainContent) {
  skipLink.addEventListener("click", (event) => {
    event.preventDefault();
    mainContent.focus();
  });
}
